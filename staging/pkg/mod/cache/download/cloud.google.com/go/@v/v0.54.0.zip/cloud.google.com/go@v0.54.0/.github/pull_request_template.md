# Wait!

**This project does not accept pull requests.**

Please see [CONTRIBUTING.md](https://github.com/googleapis/google-cloud-go/blob/master/CONTRIBUTING.md) for instructions for how to contribute.

Thank you for contributing!
