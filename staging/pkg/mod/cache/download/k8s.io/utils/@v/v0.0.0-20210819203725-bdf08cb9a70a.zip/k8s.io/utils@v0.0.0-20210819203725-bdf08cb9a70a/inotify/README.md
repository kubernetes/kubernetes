This is a fork of golang.org/x/exp/inotify before it was deleted.

Please use gopkg.in/fsnotify.v0 instead.

For updates, see: https://fsnotify.org/
