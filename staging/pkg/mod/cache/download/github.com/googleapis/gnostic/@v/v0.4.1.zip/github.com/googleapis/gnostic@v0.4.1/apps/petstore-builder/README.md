# OpenAPI Builder Sample

This directory contains a simple sample application that builds
and exports an OpenAPI 2.0 description of a sample API.

