package main

const PKG_NAME = "go-vhd"
const PKG_VERSION = "0.1"
