// cdn_serviceassets_v1
package testing
