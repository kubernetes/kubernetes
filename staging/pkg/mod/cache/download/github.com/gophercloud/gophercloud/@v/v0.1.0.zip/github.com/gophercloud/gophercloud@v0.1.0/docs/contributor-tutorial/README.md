Contributor Tutorial
====================

This tutorial is to help new contributors become familiar with the processes
used by the Gophercloud team when adding a new feature or fixing a bug.

While we have a defined process for working on Gophercloud, we're very mindful
that everyone is new to this in the beginning. Please reach out for help or ask
for clarification if needed. No question is ever "dumb" or not worth our time
answering.

To begin, go to [Step 1](step-01-introduction.md).
